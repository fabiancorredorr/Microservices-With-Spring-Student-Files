package co.fabian.corredor.lab3.sentence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentenceApplicationTests {

	@Test
	void contextLoads() {
	}

}

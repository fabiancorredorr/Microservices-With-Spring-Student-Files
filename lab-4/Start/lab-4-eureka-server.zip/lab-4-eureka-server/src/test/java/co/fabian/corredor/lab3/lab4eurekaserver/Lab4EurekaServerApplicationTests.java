package co.fabian.corredor.lab3.lab4eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}

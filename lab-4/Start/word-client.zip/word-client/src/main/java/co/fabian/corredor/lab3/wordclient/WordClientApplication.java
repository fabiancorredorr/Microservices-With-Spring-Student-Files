package co.fabian.corredor.lab3.wordclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(WordClientApplication.class, args);
	}

}
